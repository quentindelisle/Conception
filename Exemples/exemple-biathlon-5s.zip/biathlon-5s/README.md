# Biathlon 5 s – N'EPS numérique

CA1 · Course de 5 s et lancer long

PWA de suivi élèves. Conçue avec la Fabrique N'EPS (même socle que les applis Biathlon et Musculation) :
tablette enseignant ↔ tablettes élèves par QR codes, hors-ligne, données stockées sur chaque appareil.

## Mise en ligne
Publier ce dossier sur GitHub Pages ou La Forge (HTTPS obligatoire pour la caméra et l'installation ; `.gitlab-ci.yml` fourni).
iPad : Safari → Partager → « Sur l'écran d'accueil ». Android : Chrome → « Installer l'application ».
Mise à jour : ré-exporter depuis la Fabrique (la version et `CACHE` dans `sw.js` changent, les tablettes rechargent l'appli).

## Saisies
- **S · Sprint 5 s (plot atteint)** — Molette de 0 à 11, par tentative (meilleure tentative), cible par élève.
- **L · Lancer long (plot atteint)** — Molette de 0 à 8, par tentative (meilleure tentative), cible par élève.
- **T · Total des points** — Calcul : `S + L`, par tentative (meilleure tentative).
- **A · Calcul** — Calcul : `MAX(S;L) * 2`, par tentative (meilleure tentative).

## Déroulement d'une leçon
1. Tablette enseignant (code par défaut 0000) : classe, élèves (import Pronote / Excel), groupes de couleur (= tablettes), leçon en cours, tentatives (3 par défaut).
2. Appel, cibles, rôles (Pratiquant / Observateur / Starter).
3. 📲 QR de la leçon ; chaque tablette élève : Accueil → 📷 Recevoir la leçon.
4. Élèves : Saisie → tuile de l'élève → saisies.
5. Fin de leçon : chaque tablette 📤 Envoyer mes saisies ; l'enseignant 📥 Récupérer les saisies.
6. Résultats, notes, export Excel, sauvegarde.

## Échange par QR
Données compressées et codées en Base45, découpées en une série de QR qui défilent. Scanner : 30–40 cm, luminosité au maximum ;
touchez un numéro manquant pour l'afficher. Secours : « Photo du QR » ou partage en fichier (AirDrop / Partage à proximité).

Identifiant de l'appli : `biathlon-5s-zrsu` · version 1.0.0
