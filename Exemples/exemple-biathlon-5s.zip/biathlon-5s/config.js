/* Biathlon 5 s — configuration de l'activité (Fabrique N'EPS v1.0.0, 02/11/2026).
   Pour modifier l'appli : ouvrez fabrique-config.json dans la Fabrique N'EPS, puis ré-exportez. */
window.APP_CONFIG = {
 "name": "Biathlon 5 s",
 "short": "Biathlon 5s",
 "sub": "CA1 · Course de 5 s et lancer long",
 "lessons": 8,
 "attempts": 3,
 "fields": [
  {
   "label": "Sprint 5 s (plot atteint)",
   "code": "S",
   "type": "dial",
   "per": "try",
   "min": 0,
   "max": 11,
   "step": 1,
   "agg": "best",
   "better": "high",
   "target": true,
   "help": "Plot 1 = 15 km/h, +1 km/h par plot.",
   "id": "f1",
   "dec": 1,
   "show": true
  },
  {
   "label": "Lancer long (plot atteint)",
   "code": "L",
   "type": "dial",
   "per": "try",
   "min": 0,
   "max": 8,
   "step": 1,
   "agg": "best",
   "better": "high",
   "target": true,
   "help": "Plot 1 à 4 m, un plot tous les 2 m.",
   "id": "f2",
   "dec": 1,
   "show": true
  },
  {
   "label": "Total des points",
   "code": "T",
   "type": "calc",
   "per": "try",
   "formula": "S + L",
   "agg": "best",
   "better": "high",
   "dec": 0,
   "id": "f3",
   "min": 0,
   "max": 10,
   "step": 1,
   "show": true
  },
  {
   "id": "f7yiw5",
   "type": "calc",
   "label": "Calcul",
   "target": false,
   "formula": "MAX(S;L) * 2",
   "per": "try",
   "dec": 1,
   "code": "A",
   "min": 0,
   "max": 10,
   "step": 1,
   "agg": "best",
   "better": "high",
   "show": true
  }
 ],
 "roles": [
  {
   "n": "Pratiquant",
   "d": "Je cours et je lance"
  },
  {
   "n": "Observateur",
   "d": "Je repère le plot atteint"
  },
  {
   "n": "Starter",
   "d": "Je donne le départ et je chronomètre 5 s"
  }
 ],
 "rotate": true,
 "grade": {
  "on": true,
  "total": 20,
  "items": [
   {
    "field": "f1",
    "from": "best",
    "pts": 6,
    "table": [
     [
      0,
      0
     ],
     [
      11,
      6
     ]
    ]
   },
   {
    "field": "f2",
    "from": "best",
    "pts": 6,
    "table": [
     [
      0,
      0
     ],
     [
      8,
      6
     ]
    ]
   },
   {
    "field": "f1",
    "from": "cible",
    "pts": 8,
    "label": "Atteinte des cibles (sprint)",
    "table": [
     [
      0,
      0
     ],
     [
      100,
      8
     ]
    ]
   }
  ]
 },
 "id": "biathlon-5s-zrsu",
 "version": "1.0.0",
 "author": "",
 "color": "#0062C4",
 "accent": "#F59A1B",
 "maxGroups": 8
};
