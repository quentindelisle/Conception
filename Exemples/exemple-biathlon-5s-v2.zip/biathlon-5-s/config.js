/* Biathlon 5 s — configuration de l'activité (Fabrique N'EPS v2.0.0, 03/11/2026).
   Pour modifier l'appli : ouvrez fabrique-config.json dans la Fabrique N'EPS, puis ré-exportez. */
window.APP_CONFIG = {
 "name": "Biathlon 5 s",
 "short": "Biathlon 5 s",
 "sub": "CA1 · Course de 5 s et lancer long",
 "lessons": 8,
 "attempts": 3,
 "fields": [
  {
   "id": "spr",
   "label": "Sprint 5 s (plot atteint)",
   "type": "dial",
   "per": "try",
   "min": 0,
   "max": 11,
   "step": 1,
   "agg": "best",
   "better": "high",
   "target": true,
   "help": "Plot 1 = 15 km/h, +1 km/h par plot.",
   "dec": 1,
   "show": true
  },
  {
   "id": "lan",
   "label": "Lancer long (plot atteint)",
   "type": "dial",
   "per": "try",
   "min": 0,
   "max": 8,
   "step": 1,
   "agg": "best",
   "better": "high",
   "target": true,
   "help": "Plot 1 à 4 m, un plot tous les 2 m.",
   "dec": 1,
   "show": true
  },
  {
   "id": "tot",
   "label": "Total des points",
   "type": "calc",
   "per": "try",
   "formula": "{spr} + {lan}",
   "agg": "best",
   "better": "high",
   "dec": 0,
   "min": 0,
   "max": 10,
   "step": 1,
   "show": true
  }
 ],
 "roles": [
  {
   "n": "Pratiquant",
   "d": "Je cours et je lance"
  },
  {
   "n": "Observateur",
   "d": "Je repère le plot atteint"
  },
  {
   "n": "Starter",
   "d": "Je donne le départ et je chronomètre 5 s"
  }
 ],
 "rotate": true,
 "grade": {
  "on": true,
  "total": 20,
  "items": [
   {
    "field": "spr",
    "from": "best",
    "pts": 6,
    "table": [
     [
      0,
      0
     ],
     [
      11,
      6
     ]
    ]
   },
   {
    "field": "lan",
    "from": "best",
    "pts": 6,
    "table": [
     [
      0,
      0
     ],
     [
      8,
      6
     ]
    ]
   },
   {
    "field": "spr",
    "from": "cible",
    "pts": 8,
    "table": [
     [
      0,
      0
     ],
     [
      100,
      8
     ]
    ]
   }
  ]
 },
 "tools": {
  "timer": {
   "on": true,
   "el": true,
   "presets": "5, 30, 60"
  },
  "tirage": {
   "on": true,
   "el": false
  },
  "score": {
   "on": true,
   "el": true,
   "a": "Équipe A",
   "b": "Équipe B"
  }
 },
 "mode": "cycle",
 "id": "biathlon-5-s-ayvh",
 "version": "1.0.0",
 "color": "#0062C4",
 "accent": "#F59A1B",
 "maxGroups": 8
};
